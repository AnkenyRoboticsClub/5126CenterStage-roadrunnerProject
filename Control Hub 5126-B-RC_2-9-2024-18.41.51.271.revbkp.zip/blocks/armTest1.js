// IDENTIFIERS_USED=armMotorAsDcMotor,gamepad1

/**
 * This function is executed when this OpMode is selected from the Driver Station.
 */
function runOpMode() {
  armMotorAsDcMotor.setMode("RUN_WITHOUT_ENCODER");
  linearOpMode.waitForStart();
  if (linearOpMode.opModeIsActive()) {
    while (linearOpMode.opModeIsActive()) {
      armMotorAsDcMotor.setPower(gamepad1.getLeftStickY() * 1);
      telemetry.update();
    }
  }
}
